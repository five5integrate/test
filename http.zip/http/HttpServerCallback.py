class HttpServerCallback:
    httpRequestCallback = None

    def __init__(self, httpRequestCallback):
        self.httpRequestCallback = httpRequestCallback

    def httpRequest(self, request):
        return self.httpRequestCallback(request)

