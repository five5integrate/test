from http.parser.HttpRequest import HttpResponse


class HttpParser:

    def parseRequest(self, raw_request):

        method = raw_request.split(b' ', 1)[0]
        path = raw_request.split(b' ', 1)[1].split(b' ', 1)[0]

        body_split = raw_request.split(b'\r\n\r\n')

        raw_headers = body_split[0].split(b'\r\n')[1:]
        headers = {}
        for header in raw_headers:
            headers_split = header.split(b': ', 1)
            headers[headers_split[0]] = headers_split[1]

        body = b''

        if len(body_split) == 2:
            body = body_split[1]

        http_response = HttpResponse(method, path, headers, body)

        return http_response

