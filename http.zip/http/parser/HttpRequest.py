class HttpResponse:
    method = b''
    headers = {}
    body = b''

    def __init__(self, method, path, headers, body):
        self.method = method
        self.path = path
        self.headers = headers
        self.body = body
