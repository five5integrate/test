import socket
from threading import Thread

from http.parser.HttpParser import HttpParser

GET_REQUEST = b'GET '
POST_REQUEST = b'POST '
DEFAULT_HTTP_HOST = '127.0.0.1'
DEFAULT_HTTP_PORT = 8888


class HttpServer(Thread):
    host = None
    port = None
    httpServerCallback = None

    def __init__(self, http_server_callback, host=DEFAULT_HTTP_HOST, port=DEFAULT_HTTP_PORT):
        Thread.__init__(self)
        self.host = host
        self.port = port
        self.httpServerCallback = http_server_callback

    def run(self):
        listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listen_socket.bind((self.host, self.port))
        listen_socket.listen(1)
        print('[+] Running HTTP server at {}:{}'.format(self.host, self.port))
        while True:
            client_connection, client_address = listen_socket.accept()
            self.listenForRequest(client_connection)

    def listenForRequest(self, client_connection):
        raw_request = client_connection.recv(4096)

        request = HttpParser().parseRequest(raw_request)
        response = self.httpServerCallback.httpRequest(request)

        #print('[+] Sending response \'{}\''.format(response))

        client_connection.send(b'HTTP/1.1 200 OK\n')
        client_connection.send(b'Content-Type: text/html\n')
        client_connection.send(b'\n')
        client_connection.sendall(response)

        client_connection.close()
